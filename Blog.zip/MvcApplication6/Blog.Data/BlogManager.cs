﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog.Data
{
    public class BlogManager
    {
        private string _connectionString;
        public BlogManager(string connectionString)
        {
            _connectionString = connectionString;
        }
        public IEnumerable<Blogs> GetAllPosts()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM BlogData order by Date desc";
                connection.Open();
                List<Blogs> posts = new List<Blogs>();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Blogs newPost = new Blogs();
                    newPost.Id = (int)reader["Id"];
                    newPost.Author = (string)reader["Author"];
                    newPost.Title = (string)reader["Title"];
                    newPost.Text = (string)reader["Text"];
                    newPost.Date = (DateTime)reader["Date"];
                    posts.Add(newPost);
                }

                return posts;
            }
        }

            
        
        public int Add(Blogs post)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand command = connection.CreateCommand();
                command.CommandText = "INSERT INTO BlogData (Author, Date, Text, Title) " +
                                      "VALUES(@author, @date, @text, @title); SELECT @@Identity";
                command.Parameters.AddWithValue("@author", post.Author);
                command.Parameters.AddWithValue("@title", post.Title);
                command.Parameters.AddWithValue("@text", post.Text);
                command.Parameters.AddWithValue("@date", DateTime.Now);
                connection.Open();
                return (int)(decimal)command.ExecuteScalar();
            }
        }
    }
}