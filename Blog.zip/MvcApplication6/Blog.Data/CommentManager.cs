﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog.Data
{
    public class CommentManager
    {
        private string _connectionString;
        public CommentManager(string connectionString)
        {
            _connectionString = connectionString;
        }
        public IEnumerable<Comment> GetAllComments(int blogId)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM CommentData where BlogId in('blogId') order by Date desc";
                connection.Open();
                List<Comment> comments = new List<Comment>();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Comment newComment = new Comment();
                    newComment.Id = (int)reader["Id"];
                    newComment.Author = (string)reader["Author"];
                    newComment.Title = (string)reader["Title"];
                    newComment.Text = (string)reader["Text"];
                    newComment.Date = (DateTime)reader["Date"];
                    comments.Add(newComment);
                }

                return comments;
            }
        }
        public int Add(Comment comment)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand command = connection.CreateCommand();
                command.CommandText = "INSERT INTO CommentData (Author, Date, Text, Title) " +
                                      "VALUES(@author, @date, @text, @title); SELECT @@Identity";
                command.Parameters.AddWithValue("@author", comment.Author);
                command.Parameters.AddWithValue("@title", comment.Title);
                command.Parameters.AddWithValue("@text", comment.Text);
                command.Parameters.AddWithValue("@date", DateTime.Now);
                connection.Open();
                return (int)(decimal)command.ExecuteScalar();
            }
        }
    }
}
