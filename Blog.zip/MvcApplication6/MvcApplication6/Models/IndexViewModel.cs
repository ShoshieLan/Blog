﻿using Blog.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication6.Models
{
    public class IndexViewModel
    {

        public IEnumerable<Blogs> Blogs { get; set; }
       

    }
}