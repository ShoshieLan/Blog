﻿using Blog.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication6.Models
{
    public class SingleViewModel
    {

        public IEnumerable<Comment> Comments { get; set; }
        public IEnumerable<int> BlogIds { get; set; }

    }
}