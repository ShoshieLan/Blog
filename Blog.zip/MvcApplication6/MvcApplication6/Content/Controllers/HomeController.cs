﻿using Blog.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication6.Controllers
{
    public class HomeController : Controller
    {
        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Single()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddBlog(string author, string title, string text)
        {
            BlogManager manager = new BlogManager(Properties.Settings.Default.Setting);
            int id = manager.Add(new Blogs
            {
                Author = author,
                Title = title,
                Text = text
            });

            return Redirect("/Home/Index");

        }

        [HttpPost]
        public ActionResult AddComment(string author, string title, string text, int blogId)
        {
            CommentManager manager = new CommentManager(Properties.Settings.Default.Setting);
            int id = manager.Add(new Comment
            {
                Author = author,
                Title = title,
                Text = text,
            });

            return Redirect("/Home/Index");

        }

        
    }
}
